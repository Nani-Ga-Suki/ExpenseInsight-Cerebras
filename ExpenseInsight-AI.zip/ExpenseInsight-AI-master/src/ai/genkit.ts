import {genkit} from 'genkit';
// import {googleAI} from '@genkit-ai/googleai'; // Removed as per user instruction to not use Gemini for the current flow

export const ai = genkit({
  plugins: [
    // googleAI() // Removed to prevent FAILED_PRECONDITION error for GEMINI_API_KEY
  ],
  // model: 'googleai/gemini-2.0-flash', // Removed as it depends on the googleAI() plugin
  // Add other plugins here if needed, that do not depend on Google AI services,
  // or ensure GEMINI_API_KEY is set if googleAI plugin is re-enabled.
});
