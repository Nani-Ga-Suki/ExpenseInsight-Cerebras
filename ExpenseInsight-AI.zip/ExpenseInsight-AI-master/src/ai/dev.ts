
import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-expenses.ts';
import '@/ai/flows/chat-with-expenses-flow.ts';

    