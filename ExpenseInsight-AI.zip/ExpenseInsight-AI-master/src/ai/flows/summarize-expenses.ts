
// Analyze user expenses using OpenRouter via Genkit AI.
'use server';
/**
 * @fileOverview Analyzes user-provided expense data using the OpenRouter API
 * to access a Cerebras-compatible model, orchestrated via a Genkit flow.
 * It provides insights into spending habits, potential impulsive purchases,
 * health-related spending, and offers expense management advice.
 *
 * - analyzeExpenses - A function that accepts expense data and returns an analysis.
 * - AnalyzeExpensesInput - The input type for the analyzeExpenses function.
 * - AnalyzeExpensesOutput - The return type for the analyzeExpenses function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeExpensesInputSchema = z.object({
  expenses: z.string().describe('The user-provided expenses data in free-form text.'),
  model: z.string().describe('The AI model to use for analysis.'),
  provider: z.string().optional().describe('The specific provider for the model on OpenRouter.'),
  temperature: z.number().optional().describe('The temperature for the model.'),
  top_p: z.number().optional().describe('The top_p for the model.'),
  max_tokens: z.number().optional().describe('The max_tokens for the model.'),
  openRouterApiKey: z.string().optional().describe('Optional OpenRouter API key provided from UI settings.'),
});
export type AnalyzeExpensesInput = z.infer<typeof AnalyzeExpensesInputSchema>;

const AnalyzeExpensesOutputSchema = z.object({
  insights: z.string().describe('The detailed analysis and insights on the expenses data, including advice, formatted in Markdown.'),
});
export type AnalyzeExpensesOutput = z.infer<typeof AnalyzeExpensesOutputSchema>;

export async function analyzeExpenses(input: AnalyzeExpensesInput): Promise<AnalyzeExpensesOutput> {
  return analyzeExpensesFlow(input);
}

const analyzeExpensesFlow = ai.defineFlow(
  {
    name: 'analyzeExpensesFlow',
    inputSchema: AnalyzeExpensesInputSchema,
    outputSchema: AnalyzeExpensesOutputSchema,
  },
  async (input: AnalyzeExpensesInput) => {
    const apiKey = input.openRouterApiKey || process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      throw new Error('OpenRouter API key is not configured. Please set it in the app settings or as an environment variable (OPENROUTER_API_KEY).');
    }

    const url = "https://openrouter.ai/api/v1/chat/completions";
    const headers = {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        // Recommended for OpenRouter to identify your app
        "HTTP-Referer": typeof window !== 'undefined' ? window.location.hostname : 'expenseinsight-ai-app', 
        "X-Title": "ExpenseInsight AI",
    };

    const requestPayload: any = {
        "model": input.model,
        "messages": [
            {
                "role": "system",
                "content": `You are an expert financial analyst and advisor. You are provided with a user's raw expense data.
Your task is to analyze these expenses thoroughly and provide actionable insights and advice. Do not merely summarize the expenses.
Focus on the following areas:
1.  Spending Habits: Identify categories where the user spends a significant portion of their money. Highlight any unusual or noteworthy patterns.
2.  Potential Impulsive Purchases: Based on the item descriptions and amounts, flag any expenses that might indicate impulsive buying behavior. Explain your reasoning.
3.  Personal Health & Wellness: Analyze expenses related to health, such as gym memberships, healthy food purchases, medical bills, versus expenses on fast food, alcohol, or other potentially unhealthy habits. Offer observations on their apparent attention to personal health.
4.  Expense Management Advice: Provide practical and personalized tips on how the user can better manage their expenses, save money, or make more informed financial decisions based on YOUR analysis of THEIR specific expenses.
5.  Overall Financial Picture: Give a brief overview of what the expenses suggest about the user's financial priorities or lifestyle.

Structure your response clearly using Markdown. Use headings (e.g., \`## Spending Habits\`) for sections and bullet points (\`-\` or \`*\`) for lists. Use bold text (\`**text**\`) for emphasis where appropriate.
Be empathetic and constructive in your advice.
Provide only the insights and advice, without any introductory or concluding remarks unrelated to the analysis itself. The output should be Markdown text suitable for direct display.`
            },
            {
                "role": "user",
                "content": input.expenses
            }
        ],
        "temperature": input.temperature ?? 0.3,
        "top_p": input.top_p ?? 0.95,
        "max_tokens": input.max_tokens ?? 2048,
    };

    if (input.provider) {
      requestPayload.provider = { "only": [input.provider] };
    }


    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(requestPayload)
      });

      const responseData = await response.json();

      if (!response.ok) {
        // Handle HTTP errors (e.g., 4xx, 5xx)
        const errorBody = responseData.error?.message || JSON.stringify(responseData);
        console.error("OpenRouter API Error (Analysis) - HTTP Error:", response.status, errorBody);
        throw new Error(`OpenRouter API request failed with status ${response.status}: ${errorBody}`);
      }
      
      // Check for error object in the response body even if status is 200 OK
      if (responseData.error) {
        console.error("OpenRouter API Error (Analysis) - Payload Error:", responseData.error);
        throw new Error(`OpenRouter API returned an error: ${responseData.error.message || JSON.stringify(responseData.error)}`);
      }

      if (responseData.choices && responseData.choices.length > 0 && responseData.choices[0].message && responseData.choices[0].message.content) {
        const insightsText = responseData.choices[0].message.content.trim();
        return { insights: insightsText };
      } else {
        console.error("Unexpected response structure from OpenRouter (Analysis):", responseData);
        throw new Error('Failed to get a valid analysis from the OpenRouter API. The response structure was unexpected.');
      }

    } catch (error) {
      console.error("Error calling OpenRouter API (Analysis):", error);
      if (error instanceof Error) {
         if (error.message.startsWith('Failed to get a valid analysis') || error.message.startsWith('OpenRouter API request failed') || error.message.startsWith('OpenRouter API returned an error:') || error.message.startsWith('OpenRouter API key is not configured')) {
          throw error;
        }
        throw new Error(`Failed to get expense analysis via OpenRouter: ${error.message}`);
      }
      throw new Error('An unknown error occurred while trying to get expense analysis via OpenRouter.');
    }
  }
);
    
