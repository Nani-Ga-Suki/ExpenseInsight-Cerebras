
'use server';
/**
 * @fileOverview Provides a chat interface to ask follow-up questions about expenses and AI-generated insights.
 *
 * - chatWithExpenses - A function that takes original expenses, initial insights, chat history, and a new question, then returns an AI response.
 * - ChatWithExpensesInput - The input type for the chatWithExpenses function.
 * - ChatWithExpensesOutput - The return type for the chatWithExpenses function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChatMessageSchema = z.object({
  role: z.enum(['user', 'assistant']),
  content: z.string(),
});

const ChatWithExpensesInputSchema = z.object({
  originalExpenses: z.string().describe("The original, full text of the user's expenses."),
  initialInsights: z.string().describe("The initial AI-generated insights about the user's expenses, formatted in Markdown."),
  conversation: z.array(ChatMessageSchema)
    .describe("The ongoing conversation history between the user and the assistant, not including the latest user question which is passed separately."),
  currentQuestion: z.string().describe("The user's latest question about the expenses or insights."),
  model: z.string().describe('The AI model to use for chat responses.'),
  provider: z.string().optional().describe('The specific provider for the model on OpenRouter.'),
  temperature: z.number().optional().describe('The temperature for the model.'),
  top_p: z.number().optional().describe('The top_p for the model.'),
  max_tokens: z.number().optional().describe('The max_tokens for the model.'),
  openRouterApiKey: z.string().optional().describe('Optional OpenRouter API key provided from UI settings.'),
});
export type ChatWithExpensesInput = z.infer<typeof ChatWithExpensesInputSchema>;

const ChatWithExpensesOutputSchema = z.object({
  response: z.string().describe("The AI's answer to the user's question, formatted in Markdown."),
});
export type ChatWithExpensesOutput = z.infer<typeof ChatWithExpensesOutputSchema>;

export async function chatWithExpenses(input: ChatWithExpensesInput): Promise<ChatWithExpensesOutput> {
  return chatWithExpensesFlow(input);
}

const chatWithExpensesFlow = ai.defineFlow(
  {
    name: 'chatWithExpensesFlow',
    inputSchema: ChatWithExpensesInputSchema,
    outputSchema: ChatWithExpensesOutputSchema,
  },
  async (input: ChatWithExpensesInput) => {
    const apiKey = input.openRouterApiKey || process.env.OPENROUTER_API_KEY;
    if (!apiKey) {
      throw new Error('OpenRouter API key is not configured. Please set it in the app settings or as an environment variable (OPENROUTER_API_KEY).');
    }

    const url = "https://openrouter.ai/api/v1/chat/completions";
    const headers = {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        // Recommended for OpenRouter to identify your app
        "HTTP-Referer": typeof window !== 'undefined' ? window.location.hostname : 'expenseinsight-ai-app', 
        "X-Title": "ExpenseInsight AI",
    };

    const filteredConversation = input.conversation.map(msg => ({role: msg.role, content: msg.content}));

    const requestPayload: any = {
        "model": input.model,
        "messages": [
          {
            role: "system",
            content: `You are an expert financial assistant. You are provided with a user's raw expense data, the initial AI-generated insights about these expenses (which were formatted in Markdown), and an ongoing conversation.
Your task is to answer the user's follow-up questions based *only* on the provided expense data, the initial insights, and the conversation history.
Do not make up information or answer questions outside of this scope. Be concise and helpful.
Format your responses using Markdown (e.g., use **bold** for emphasis, \`-\` or \`*\` for bullet points, \`## Heading\` for headings if appropriate) for better readability.

User's original expense data:
---
${input.originalExpenses}
---
Initial AI Insights previously provided (in Markdown):
---
${input.initialInsights}
---`
          },
          ...filteredConversation,
          { role: "user", content: input.currentQuestion }
        ],
        "temperature": input.temperature ?? 0.5,
        "top_p": input.top_p ?? 0.95,
        "max_tokens": input.max_tokens ?? 4096,
    };

    if (input.provider) {
      requestPayload.provider = { "only": [input.provider] };
    }

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(requestPayload)
      });

      const responseData = await response.json();

      if (!response.ok) {
         // Handle HTTP errors (e.g., 4xx, 5xx)
        const errorBody = responseData.error?.message || JSON.stringify(responseData);
        console.error("OpenRouter API Error (Chat) - HTTP Error:", response.status, errorBody);
        throw new Error(`OpenRouter API request failed with status ${response.status}: ${errorBody}`);
      }

      // Check for error object in the response body even if status is 200 OK
      if (responseData.error) {
        console.error("OpenRouter API Error (Chat) - Payload Error:", responseData.error);
        throw new Error(`OpenRouter API returned an error: ${responseData.error.message || JSON.stringify(responseData.error)}`);
      }

      if (responseData.choices && responseData.choices.length > 0 && responseData.choices[0].message && responseData.choices[0].message.content) {
        const aiResponse = responseData.choices[0].message.content.trim();
        return { response: aiResponse };
      } else {
        console.error("Unexpected response structure from OpenRouter (Chat):", responseData);
        throw new Error('Failed to get a valid response from the OpenRouter API for chat. The response structure was unexpected.');
      }

    } catch (error) {
      console.error("Error calling OpenRouter API (Chat):", error);
      if (error instanceof Error) {
         if (error.message.startsWith('Failed to get a valid response') || error.message.startsWith('OpenRouter API request failed') || error.message.startsWith('OpenRouter API returned an error:') || error.message.startsWith('OpenRouter API key is not configured')) {
          throw error;
        }
        throw new Error(`Failed to get chat response via OpenRouter: ${error.message}`);
      }
      throw new Error('An unknown error occurred while trying to get chat response via OpenRouter.');
    }
  }
);
    
