
"use client";

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles, Trash2, MessageSquare, SendHorizonal, Brain, Settings, Check, FileUp } from "lucide-react";
import { analyzeExpenses, type AnalyzeExpensesInput, type AnalyzeExpensesOutput } from "@/ai/flows/summarize-expenses";
import { chatWithExpenses, type ChatWithExpensesInput, type ChatWithExpensesOutput } from "@/ai/flows/chat-with-expenses-flow";
import { useToast } from "@/hooks/use-toast";
import { ScrollArea } from "@/components/ui/scroll-area";
import ReactMarkdown from "react-markdown";
import * as XLSX from 'xlsx';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface AIBackendConfig {
  id: string;
  label: string;
  model: string;
  provider?: string;
  apiKeyRequired: "OPENROUTER_API_KEY" | "CEREBRAS_API_KEY" | "NONE";
  temperature?: number;
  top_p?: number;
  max_tokens?: number;
}

const availableBackends: AIBackendConfig[] = [
  {
    id: "openrouter-cerebras-llama3.3-70b",
    label: "OpenRouter (Provider: Cerebras, Model: Llama3.3-70B)",
    model: "meta-llama/llama-3.3-70b-instruct",
    provider: "Cerebras",
    apiKeyRequired: "OPENROUTER_API_KEY",
  },
  {
    id: "openrouter-cerebras-qwen3-32b-snippet",
    label: "OpenRouter (Cerebras Qwen3-32B - Snippet Params)",
    model: "qwen/qwen3-32b",
    provider: "Cerebras",
    apiKeyRequired: "OPENROUTER_API_KEY",
    temperature: 0.7,
    top_p: 0.95,
    max_tokens: 16382
  },
  {
    id: "openrouter-chutes-qwen3-30b",
    label: "OpenRouter (Provider: Chutes, Model: Qwen3-30B Free)",
    model: "qwen/qwen3-30b-a3b:free",
    provider: "Chutes",
    apiKeyRequired: "OPENROUTER_API_KEY",
  },
];


export default function ExpenseAIPage() {
  const [expenseInput, setExpenseInput] = useState<string>("");
  const [insights, setInsights] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { toast } = useToast();
  const [currentYear, setCurrentYear] = useState<number | null>(null);

  const [showChatWindow, setShowChatWindow] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState<string>("");
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const chatEndRef = useRef<null | HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedBackend, setSelectedBackend] = useState<AIBackendConfig>(availableBackends[0]);
  const [isConfigPopoverOpen, setIsConfigPopoverOpen] = useState(false);

  const [uiOpenRouterApiKey, setUiOpenRouterApiKey] = useState<string>("");
  const [uiCerebrasApiKey, setUiCerebrasApiKey] = useState<string>("");

  // Load API keys from localStorage on mount
  useEffect(() => {
    const storedOpenRouterKey = localStorage.getItem("expenseInsightAIOpenRouterApiKey");
    if (storedOpenRouterKey) {
      setUiOpenRouterApiKey(storedOpenRouterKey);
    }
    const storedCerebrasKey = localStorage.getItem("expenseInsightAICerebrasApiKey");
    if (storedCerebrasKey) {
      setUiCerebrasApiKey(storedCerebrasKey);
    }
  }, []);

  // Save OpenRouter API key to localStorage when it changes
  useEffect(() => {
    if (uiOpenRouterApiKey) {
      localStorage.setItem("expenseInsightAIOpenRouterApiKey", uiOpenRouterApiKey);
    } else {
      localStorage.removeItem("expenseInsightAIOpenRouterApiKey");
    }
  }, [uiOpenRouterApiKey]);

  // Save Cerebras API key to localStorage when it changes
  useEffect(() => {
    if (uiCerebrasApiKey) {
      localStorage.setItem("expenseInsightAICerebrasApiKey", uiCerebrasApiKey);
    } else {
      localStorage.removeItem("expenseInsightAICerebrasApiKey");
    }
  }, [uiCerebrasApiKey]);


  useEffect(() => {
    setCurrentYear(new Date().getFullYear());
  }, []);

  useEffect(() => {
    if (showChatWindow) {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatMessages, showChatWindow]);


  const handleAnalyzeExpenses = async () => {
    if (!expenseInput.trim()) {
      toast({
        title: "Input Required",
        description: "Please enter your expenses or upload a file before analyzing.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setInsights("");
    setChatMessages([]);
    setShowChatWindow(false);

    try {
      const startTime = performance.now();
      const analysisInput: AnalyzeExpensesInput = {
        expenses: expenseInput,
        model: selectedBackend.model,
        provider: selectedBackend.provider,
        temperature: selectedBackend.temperature,
        top_p: selectedBackend.top_p,
        max_tokens: selectedBackend.max_tokens,
        openRouterApiKey: uiOpenRouterApiKey || undefined,
      }
      const result: AnalyzeExpensesOutput = await analyzeExpenses(analysisInput);
      const endTime = performance.now();
      const duration = ((endTime - startTime) / 1000).toFixed(2);

      setInsights(result.insights);
      setShowChatWindow(true);
      setChatMessages([
        { role: 'assistant', content: `Here are insights on your expenses (using ${selectedBackend.label}):\n\n${result.insights}\n\nWhat else can I help you with regarding these expenses or insights?` }
      ]);
      toast({
        title: "Insights Ready!",
        description: `Expense analysis generated in ${duration} seconds using ${selectedBackend.label}. You can now chat about them.`,
        variant: "default",
      });
    } catch (error) {
      console.error("Error analyzing expenses:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      toast({
        title: "Error Analyzing Expenses",
        description: `Failed to analyze expenses. ${errorMessage.includes("API key") ? "Please ensure your API key is configured in settings or environment variables." : errorMessage.includes("OpenRouter API request failed") ? "The AI model might be unavailable or an API error occurred." : "Please try again later."}`,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendChatMessage = async () => {
    if (!chatInput.trim() || isChatLoading || !insights) return;

    const newUserMessage: ChatMessage = { role: 'user', content: chatInput };
    setChatMessages(prev => [...prev, newUserMessage]);
    setChatInput("");
    setIsChatLoading(true);

    try {
      const startTime = performance.now();
      const conversationHistory = chatMessages.filter(msg => msg.role === 'user' || msg.role === 'assistant');

      const chatInputPayload: ChatWithExpensesInput = {
        originalExpenses: expenseInput,
        initialInsights: insights,
        conversation: conversationHistory,
        currentQuestion: newUserMessage.content,
        model: selectedBackend.model,
        provider: selectedBackend.provider,
        temperature: selectedBackend.temperature,
        top_p: selectedBackend.top_p,
        max_tokens: selectedBackend.max_tokens,
        openRouterApiKey: uiOpenRouterApiKey || undefined,
      };

      const result: ChatWithExpensesOutput = await chatWithExpenses(chatInputPayload);
      const endTime = performance.now();
      const duration = ((endTime - startTime) / 1000).toFixed(2);

      setChatMessages(prev => [...prev, { role: 'assistant', content: result.response }]);
      toast({
        title: "AI Replied",
        description: `Response generated in ${duration} seconds using ${selectedBackend.label}.`,
        variant: "default",
      });
    } catch (error) {
      console.error("Error in chat:", error);
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setChatMessages(prev => [...prev, { role: 'assistant', content: `Sorry, I encountered an error: ${errorMessage}` }]);
      toast({
        title: "Chat Error",
        description: `Failed to get a response. ${errorMessage.includes("API key") ? "Please ensure your API key is configured in settings or environment variables." : errorMessage.includes("OpenRouter API request failed") ? "The AI model might be unavailable or an API error occurred." : "Please try again."}`,
        variant: "destructive",
      });
    } finally {
      setIsChatLoading(false);
    }
  };

  const handleClear = () => {
    setExpenseInput("");
    setInsights("");
    setShowChatWindow(false);
    setChatMessages([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; // Reset file input
    }
    toast({
        title: "Cleared",
        description: "Input, insights, and chat have been cleared.",
        variant: "default",
      });
  };

  const handleBackendChange = (newBackendId: string) => {
    const newBackend = availableBackends.find(b => b.id === newBackendId);
    if (newBackend) {
      setSelectedBackend(newBackend);
      toast({
        title: "AI Backend Changed",
        description: `Switched to ${newBackend.label}.`,
        variant: "default",
      });
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const fileContent = e.target?.result;
        if (!fileContent) {
          throw new Error("File content is empty.");
        }

        if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
          const workbook = XLSX.read(fileContent, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const csvData = XLSX.utils.sheet_to_csv(worksheet);
          setExpenseInput(csvData);
        } else { // .csv, .txt, .c
          setExpenseInput(fileContent as string);
        }
        toast({
          title: "File Loaded",
          description: `${file.name} content has been loaded into the input area.`,
          variant: "default",
        });
      } catch (error) {
        console.error("Error processing file:", error);
        const errorMessage = error instanceof Error ? error.message : "Unknown error";
        toast({
          title: "File Processing Error",
          description: `Could not process ${file.name}: ${errorMessage}`,
          variant: "destructive",
        });
      }
    };

    reader.onerror = () => {
      toast({
        title: "File Read Error",
        description: `Could not read ${file.name}.`,
        variant: "destructive",
      });
    };

    if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
      reader.readAsArrayBuffer(file);
    } else {
      reader.readAsText(file);
    }
  };


  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-background text-foreground selection:bg-primary/20 selection:text-primary">
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col items-center justify-start p-4 sm:p-6 lg:p-8 overflow-y-auto">
        <div className="w-full max-w-2xl space-y-8 relative">
          <header className="text-center space-y-3">
            <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-full mb-3 shadow-sm">
              <Brain className="h-10 w-10 sm:h-12 sm:w-12 text-primary" />
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-primary tracking-tight">ExpenseInsight AI</h1>
            <p className="text-md sm:text-lg text-muted-foreground px-2">
              Gain valuable insights into your spending habits and receive financial advice.
            </p>
             <div className="absolute top-0 right-0 mt-1 mr-1">
                <Popover open={isConfigPopoverOpen} onOpenChange={setIsConfigPopoverOpen}>
                  <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon" aria-label="AI Backend Configuration">
                      <Settings className="h-6 w-6 text-muted-foreground hover:text-primary" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-96" side="bottom" align="end">
                    <div className="grid gap-4">
                      <div className="space-y-2">
                        <h4 className="font-medium leading-none">AI Configuration</h4>
                        <p className="text-sm text-muted-foreground">
                          Select AI model, provider, and manage API keys. All current options use OpenRouter.
                        </p>
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="openrouter-api-key">OpenRouter API Key</Label>
                        <Input
                          id="openrouter-api-key"
                          type="password"
                          placeholder="Enter your OpenRouter API Key"
                          value={uiOpenRouterApiKey}
                          onChange={(e) => setUiOpenRouterApiKey(e.target.value)}
                        />
                         <p className="text-xs text-muted-foreground">
                          Takes precedence over environment variable. Stored in browser. Required for all current OpenRouter options.
                        </p>
                      </div>

                       <div className="grid gap-2">
                        <Label htmlFor="cerebras-api-key">Cerebras API Key</Label>
                        <Input
                          id="cerebras-api-key"
                          type="password"
                          placeholder="Enter your Cerebras API Key"
                          value={uiCerebrasApiKey}
                          onChange={(e) => setUiCerebrasApiKey(e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground">
                          For potential future direct Cerebras SDK integration. Stored in browser. Not used by any current OpenRouter options.
                        </p>
                      </div>


                      <Label>Select AI Backend</Label>
                      <RadioGroup
                        value={selectedBackend.id}
                        onValueChange={handleBackendChange}
                        className="grid gap-2"
                      >
                        {availableBackends.map((backend) => (
                          <div key={backend.id} className="flex items-center justify-between space-x-2 p-2 hover:bg-muted/50 rounded-md cursor-pointer" onClick={() => handleBackendChange(backend.id)}>
                            <Label htmlFor={backend.id} className="flex-1 cursor-pointer text-sm">
                              {backend.label}
                              {backend.apiKeyRequired === "OPENROUTER_API_KEY" && !uiOpenRouterApiKey && !process.env.OPENROUTER_API_KEY && (
                                <span className="text-xs text-destructive ml-1">(OpenRouter Key needed)</span>
                              )}
                               {backend.apiKeyRequired === "CEREBRAS_API_KEY" && !uiCerebrasApiKey && !process.env.CEREBRAS_API_KEY && (
                                <span className="text-xs text-destructive ml-1">(Cerebras Key needed)</span>
                              )}
                            </Label>
                            <div className="flex items-center">
                               {selectedBackend.id === backend.id && <Check className="h-4 w-4 text-primary mr-2" />}
                               <RadioGroupItem value={backend.id} id={backend.id} className="opacity-0 absolute right-0"/>
                            </div>
                          </div>
                        ))}
                      </RadioGroup>
                      <Button onClick={() => setIsConfigPopoverOpen(false)} className="mt-2 w-full">Done</Button>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
          </header>

          <Card className="shadow-xl rounded-xl overflow-hidden">
            <CardHeader className="bg-card">
              <CardTitle className="text-xl sm:text-2xl font-semibold text-card-foreground">Enter Your Expenses</CardTitle>
              <CardDescription className="text-sm">
                Paste, type your expense data, or upload a file. The more detailed, the better the insights!
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-4 sm:p-6">
              <Textarea
                placeholder="e.g., Coffee Shop $5.50 - Oct 23, Groceries $75.20 - Oct 24 (milk, bread, eggs), Dinner with friends $45 - Oct 25..."
                value={expenseInput}
                onChange={(e) => setExpenseInput(e.target.value)}
                rows={8}
                className="resize-none text-sm sm:text-base border-input focus:ring-primary"
                aria-label="Expense Input Area"
              />
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                className="hidden"
                accept=".csv,.txt,.c,.xlsx,.xls"
                aria-label="Upload expense file"
              />
              <div className="flex flex-col sm:flex-row sm:justify-between items-center gap-3 pt-2">
                <Button
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full sm:w-auto border-muted-foreground/50 hover:bg-muted/80"
                    disabled={isLoading || isChatLoading}
                    aria-label="Upload expense file button"
                  >
                    <FileUp className="mr-2 h-4 w-4" /> Upload File
                  </Button>
                <div className="flex flex-col sm:flex-row sm:justify-end gap-3 w-full sm:w-auto">
                  <Button
                    variant="outline"
                    onClick={handleClear}
                    className="w-full sm:w-auto border-muted-foreground/50 hover:bg-muted/80"
                    disabled={isLoading || isChatLoading}
                    aria-label="Clear input and insights"
                  >
                    <Trash2 className="mr-2 h-4 w-4" /> Clear
                  </Button>
                  <Button
                    onClick={handleAnalyzeExpenses}
                    disabled={isLoading || isChatLoading || !expenseInput.trim()}
                    className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-accent-foreground"
                    aria-label="Analyze expenses"
                  >
                    {isLoading ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <Sparkles className="mr-2 h-4 w-4" />
                    )}
                    Get Insights
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {isLoading && !insights && (
            <Card className="shadow-xl rounded-xl animate-pulse overflow-hidden">
              <CardHeader className="bg-card">
                <CardTitle className="text-xl sm:text-2xl font-semibold text-card-foreground">Generating Insights...</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 p-4 sm:p-6">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
                <div className="h-4 bg-muted rounded w-5/6"></div>
                <div className="h-4 bg-muted rounded w-2/3"></div>
                 <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-4 bg-muted rounded w-full"></div>
              </CardContent>
            </Card>
          )}

          {!isLoading && insights && !showChatWindow && (
             // This card is now only shown if chat window is not active.
             // The initial insights are shown directly in the chat window when it appears.
            <Card className="shadow-xl rounded-xl overflow-hidden">
              <CardHeader className="bg-card">
                <CardTitle className="text-xl sm:text-2xl font-semibold text-card-foreground">Expense Analysis & Insights</CardTitle>
                 <CardDescription>Using: {selectedBackend.label}</CardDescription>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="text-sm sm:text-base leading-relaxed text-foreground prose dark:prose-invert max-w-none">
                  <ReactMarkdown
                    components={{
                      h1: ({node, ...props}) => <h1 className="text-2xl font-bold my-3" {...props} />,
                      h2: ({node, ...props}) => <h2 className="text-xl font-semibold my-2" {...props} />,
                      h3: ({node, ...props}) => <h3 className="text-lg font-semibold my-1" {...props} />,
                      ul: ({node, ...props}) => <ul className="list-disc pl-5 my-2 space-y-1" {...props} />,
                      ol: ({node, ...props}) => <ol className="list-decimal pl-5 my-2 space-y-1" {...props} />,
                      p: ({node, ...props}) => <p className="mb-2" {...props} />,
                      strong: ({node, ...props}) => <strong className="font-semibold" {...props} />,
                    }}
                  >
                    {insights}
                  </ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          )}

          <footer className="text-center text-xs sm:text-sm text-muted-foreground pt-8">
            {currentYear !== null && <p>&copy; {currentYear} ExpenseInsight AI. Powered by Generative AI.</p>}
          </footer>
        </div>
      </div>

      {/* Chat Window Area */}
      {showChatWindow && (
        <div className="w-full md:max-w-md lg:max-w-lg xl:max-w-xl border-t md:border-t-0 md:border-l border-border bg-card flex flex-col h-screen md:h-auto max-h-screen">
          <CardHeader className="border-b">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-6 w-6 text-primary" />
              <CardTitle className="text-xl font-semibold">Chat About Expenses & Insights</CardTitle>
            </div>
            <CardDescription>Ask follow-up questions. (Using: {selectedBackend.label})</CardDescription>
          </CardHeader>

          <ScrollArea className="flex-1 p-4 space-y-4 bg-background/30">
            {chatMessages.map((msg, index) => (
              <div
                key={index}
                className={`flex mb-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`p-3 rounded-lg shadow-md max-w-[85%] text-sm ${
                  msg.role === 'user' ? 'bg-primary/80 text-primary-foreground whitespace-pre-wrap' : 'bg-muted prose dark:prose-invert prose-sm max-w-none'
                }`}>
                  {msg.role === 'user' ? (
                    msg.content
                  ) : (
                    <ReactMarkdown
                      components={{
                        h1: ({node, ...props}) => <h1 className="text-xl font-bold my-2" {...props} />,
                        h2: ({node, ...props}) => <h2 className="text-lg font-semibold my-1" {...props} />,
                        h3: ({node, ...props}) => <h3 className="text-base font-semibold my-1" {...props} />,
                        ul: ({node, ...props}) => <ul className="list-disc pl-4 my-1 space-y-0.5" {...props} />,
                        ol: ({node, ...props}) => <ol className="list-decimal pl-4 my-1 space-y-0.5" {...props} />,
                        p: ({node, ...props}) => <p className="mb-1" {...props} />,
                        strong: ({node, ...props}) => <strong className="font-semibold" {...props} />,
                        code: ({node, inline, className, children, ...props}) => {
                          const match = /language-(\w+)/.exec(className || '')
                          return !inline && match ? (
                            <div className="my-2 bg-gray-800 rounded-md p-2 overflow-x-auto">
                              <code className={`text-xs text-gray-200 ${className}`} {...props}>
                                {children}
                              </code>
                            </div>
                          ) : (
                            <code className={`text-xs bg-gray-200 dark:bg-gray-700 px-1 py-0.5 rounded-sm ${className}`} {...props}>
                              {children}
                            </code>
                          )
                        },
                      }}
                    >
                      {msg.content}
                    </ReactMarkdown>
                  )}
                </div>
              </div>
            ))}
            {isChatLoading && (
              <div className="flex justify-start mb-3">
                <div className="p-3 rounded-lg shadow-md bg-muted max-w-[85%]">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">AI is thinking...</p>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </ScrollArea>

          <CardContent className="p-4 border-t">
            <form onSubmit={(e) => { e.preventDefault(); handleSendChatMessage(); }} className="flex items-center space-x-2">
              <Textarea
                placeholder="Ask about your expenses or insights..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                rows={1}
                className="flex-1 resize-none text-sm focus:ring-primary"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendChatMessage();
                  }
                }}
                aria-label="Chat input"
                disabled={isChatLoading}
              />
              <Button type="submit" disabled={!chatInput.trim() || isChatLoading} className="bg-accent hover:bg-accent/90 text-accent-foreground" aria-label="Send chat message">
                {isChatLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <SendHorizonal className="h-4 w-4" />}
              </Button>
            </form>
          </CardContent>
        </div>
      )}
    </div>
  );
}

    