# **App Name**: ExpenseAI

## Core Features:

- Expense Input: Text area to input user expense data in various formats.
- Expense Summarization: Summarize user's expenses, calling the Cerebras API using the Qwen model as a tool.
- Summary Display: Display the summarized expenses in a concise, readable format.
- Clear Data: Ability to clear the input field and the displayed summary.

## Style Guidelines:

- Primary color: Soft, muted blue (#77B5FE) to evoke a sense of calm and trust.
- Background color: Light, desaturated blue (#F0F8FF) to provide a clean and unobtrusive backdrop.
- Accent color: Warm, inviting orange (#FF8C69) for call-to-action buttons and key information.
- Clean, sans-serif font for readability and a modern feel.
- Minimalist icons for categories of expenses.
- Simple, single-column layout to focus on the expense input and summary.
- Subtle loading animation while waiting for the expense summarization.